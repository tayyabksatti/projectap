package application;

public class wrongcniclength extends Exception  {

	 wrongcniclength(String p1)
	 {
			super(p1);
			System.out.print(p1);
	 }
	
}

package application;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.junit.Test;

import junit.framework.Assert;

public class testing {

	@Test
	public  void test()
	{
		
		REGISTER obj=new REGISTER("ALI", 12345, "3740425632887", "led-121", "12345678901", 1234, "car", 5000);
		if((obj.getName()=="ALI")&&(obj.getPassword()==12345)&&(obj.cnic=="3740425632887") &&(obj.vehicleno=="led-121")
		&&(obj.cardno=="3740425632887")&&(obj.pin==1234)
		&&(obj.vehicletype=="car")&&(obj.price==5000))
		{

			assertTrue(true);
		}
	}
	@Test
	public void test2()
	{
		
		LOGIN obj=new LOGIN("tayyab", 12345);
		if((obj.getName()=="tayyab") && (obj.getPassword()==12345))
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void test3()
	{
		String[] arr= {"ALI","12345", "3740425632887", "led-121", "12345678901", "1234", "car", "5000"};
		MEMBER obj = new MEMBER("ALI",12345, "3740425632887", "led-121", "12345678901", 1234, "car", 5000);
		obj.equals(arr);
		
		
	}
	@Test
	public void test4()
	{
	
		LOGIN obj=new LOGIN("tayyab", 12345);
		if((obj.getName()==MEMBER.name1) &&(obj.password==MEMBER.password1))
		{
			assertTrue(true);
		}
		
	}
	@Test
	public void test5() throws FileNotFoundException
	{
		
		  File myObj = new File("memberdata.txt");
	      Scanner myReader = new Scanner(myObj);
	     String expected="tayyab	12345	3740425632887	LHR-129	1233211234321112	1234	car	5000";
	 
	        String data = myReader.nextLine();
	   
	        assertEquals(expected, data);
	}
	
	@Test
	public void test6() throws FileNotFoundException
	{
		
		  File myObj = new File("memberdata.txt");
	      Scanner myReader = new Scanner(myObj);
	     String expected="tayyab	12345	3740425632887	LHR-129	1233211234321112	1234	car	5000";
	 
	        String data = myReader.nextLine();
	   
	        assertNOTEquals(expected, data);
	}
	private void assertNOTEquals(String expected, String data) {
		// TODO Auto-generated method stub
		
	}
	
	
	@Test
	public void test7() 
	{
		
	CARPARK obj=new CARPARK();
	int prev=0;
	System.out.print(obj.slotno);
	Assert.assertTrue(prev  < obj.slotno );
	}
	
	
	@Test
	public void test8() 
	{
	int p=5000;
	CARPARK obj=new CARPARK(p);
	Assert.assertTrue(p  == obj.getAmount() );
	}
	
	@Test
	public void test9() 
	{
		
	CARWASH obj=new CARWASH();
	CARPARK obj1=new CARPARK();
	assertNOTEquals(obj1.slotno, obj.slotno);

	}
	
	@Test
	public void test10() 
	{
		
	CARREPAIR obj=new CARREPAIR();
	CARPARK obj1=new CARPARK();
	assertNOTEquals(obj1.slotno, obj.slotno);

	}
	
	private void assertNOTEquals(int slotno, int slotno2) {
		// TODO Auto-generated method stub
		
	}
	@Test
	public void test11() 
	{
	
	EMPLOYEE OBJ=new EMPLOYEE("hussan", 20, "37388299203883", "car washer", 2000);
	if((OBJ.getName()=="hussan")&&(OBJ.age==20)&&(OBJ.getCnic()=="37388299203883"))
	{
		assertTrue(true);
	}
	
	
	}

}
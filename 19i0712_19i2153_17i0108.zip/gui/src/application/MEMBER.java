package application;
import java.io.BufferedReader;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.util.Scanner;

import database.MYSQL; 
public class MEMBER {

	public static String name1;
	public static int password1;
	public static boolean flag=false;
	public static String cnic;
	public static String vehicleno;
	public static String cardno;
	public static int pin;
	public static String vehicletype;
	public static int price;

	MEMBER(String n,int p,String c,String v,String cd,int pin,String vty,int pr)
	{
		name1=n;
		password1=p;
		cnic=c;
		vehicleno=v;
		cardno=cd;
		this.pin=pin;
		vehicletype=vty;
		price=pr;
	}
	
	
	public static void data(REGISTER obj) {
	    try {
	    	System.out.println("lalalalala");
	    	
	    	
	    	FileWriter myWriter = new FileWriter("memberdata.txt",true);
	        myWriter.write(obj.name+"\t");
	        myWriter.write(obj.password+"\t");
	        myWriter.write(obj.cnic+"\t");
	        myWriter.write(obj.vehicleno+"\t");
	        myWriter.write(obj.cardno+"\t");
	        myWriter.write(obj.pin+"\t");
	        myWriter.write(obj.vehicletype+"\t");
	        myWriter.write(obj.price+"\n");
	        
	    	MEMBER m=new MEMBER(obj.name,obj.password,obj.cnic,obj.vehicleno,obj.cardno,obj.pin,obj.vehicletype,obj.price);
			MYSQL OBJ=new MYSQL();
			OBJ.add_MEMBER(m);
	        myWriter.close();  
	      }
	     catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	  }
	
	public static void readdata(LOGIN OBJ) 
	{
		flag=false;
		try {
				String array[] = null;
		      File myObj = new File("memberdata.txt");
		      Scanner myReader = new Scanner(myObj);
		     
		      while (myReader.hasNextLine()) {
		        String data = myReader.nextLine();
		        System.out.print("read from file");
		        System.out.println(data);
		        String[] ar=new String[8];
		        		ar=data.split("\t");
		      
		        	//System.out.print(ar[i]+"\t");
		        	name1=ar[0];
		        	password1=Integer.valueOf(ar[1]);
		        	cnic=ar[2];
		        	vehicleno=ar[3];
		        	cardno=ar[4];
		        	pin=Integer.valueOf(ar[5]);
		        	vehicletype=ar[6];
		        	price=Integer.valueOf(ar[7]);
		     
		        	if((OBJ.name.equals(name1)) && (OBJ.password==password1))
		    		{
		        		flag=true;
		        
		        		REGISTER OBJR=new REGISTER(name1,password1,cnic,vehicleno,cardno,pin,vehicletype,price);
		        		parent.store(OBJR);
		    		
		    		}
		    
		      
		       }
		      
		      myReader.close();
		}
		      catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
	}
	
public static boolean checker(LOGIN OBJ)
	{
		if(flag==true)
		{
			System.out.print("true");
			return true;
		}
		else
			{
			
			System.out.print("false");
				return false;
			}
		
	}

public static void dataofemply(EMPLOYEE obj) {
    try {
    	System.out.println("lalalalala");
    	FileWriter myWriter = new FileWriter("employeedata.txt",true);
        myWriter.write(obj.name+"\t");
        myWriter.write(obj.cnic+"\t");
        myWriter.write(obj.pay+"\t");
        myWriter.write(obj.prof+"\t");
        myWriter.write(obj.age+"\n");
      //  EMPLOYEE m=new EMPLOYEE(obj.name,obj.cnic,obj.pay,)
        MYSQL OBJ=new MYSQL();
		OBJ.add_EMPLOYEE(obj);
        myWriter.close();  
      }
     catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
	
		
}

package application;

public class EMPLOYEE {

	public String name;
	public int age;
	public String cnic;
	public String prof;
	public int pay;
	
	
	
	public EMPLOYEE(String name, int age, String cnic, String prof, int pay) {
		super();
		this.name = name;
		this.age = age;
		this.cnic = cnic;
		this.prof = prof;
		this.pay = pay;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCnic() {
		return cnic;
	}
	public void setCnic(String cnic) {
		this.cnic = cnic;
	}
	public String getProf() {
		return prof;
	}
	public void setProf(String prof) {
		this.prof = prof;
	}
	public int getPay() {
		return pay;
	}
	public void setPay(int pay) {
		this.pay = pay;
	}
	
	
	public void display()
	{
		
		System.out.print(name+"\n");
		System.out.print(age+"\n");
		System.out.print(cnic+"\n");
		System.out.print(prof+"\n");
		System.out.print(pay+"\n");
		EMPLOYEE OBJ = new EMPLOYEE(name,age,cnic,prof,pay);
		MEMBER. dataofemply(OBJ);
		
	}
	

	
	
	
	
	
}

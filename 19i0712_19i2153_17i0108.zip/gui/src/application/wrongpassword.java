package application;

public class wrongpassword extends Exception {

	public wrongpassword(String p)
	{
		super(p);
		System.out.print(p);
	}


	
}

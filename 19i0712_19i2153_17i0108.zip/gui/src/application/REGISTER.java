package application;

public class REGISTER {
	
	String name;
	int password;
	String cnic;
	String vehicleno;
	String cardno;
	int pin;
	String vehicletype;
	int price;
	public REGISTER() {
		// TODO Auto-generated constructor stub
		 name=" ";
		password=0;
		cnic="";
		vehicleno="";
		cardno="";
		pin=0;
		vehicletype="";
		
	}
	public REGISTER(String name, int password, String cnic, String vehicleno, String cardno, int pin,
			String vehicletype,int price) {
		//super();
		this.name = name;
		this.password =password;
		this.cnic = cnic;
		this.vehicleno = vehicleno;
		this.cardno = cardno;
		this.pin = pin;
		this.vehicletype = vehicletype;
		this.price=price;
	}
	
	public REGISTER(REGISTER r) {
		this.name = r.name;
		this.password =r.password;
		this.cnic = r.cnic;
		this.vehicleno = r.vehicleno;
		this.cardno = r.cardno;
		this.pin = r.pin;
		this.vehicletype = r.vehicletype;
		this.price=price;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public String getCnic() {
		return cnic;
	}
	public void setCnic(String cnic) {
		this.cnic = cnic;
	}
	public String getVehicleno() {
		return vehicleno;
	}
	public void setVehicleno(String vehicleno) {
		this.vehicleno = vehicleno;
	}
	public String getCardno() {
		return cardno;
	}
	public void setCardno(String cardno) {
		this.cardno = cardno;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getVehicletype() {
		return vehicletype;
	}
	public void setVehicletype(String vehicletype) {
		this.vehicletype = vehicletype;
	}
	public void setprice(int price)
	{
		this.price=price;
	}
	
	public void display()
	{
		
		System.out.print(name+"\n");
		System.out.print(password+"\n");
		System.out.print(cnic+"\n");
		System.out.print(vehicleno+"\n");
		System.out.print(cardno+"\n");
		System.out.print(pin+"\n");
		System.out.print(vehicletype+"\t");
		System.out.print(price+"\n");
		REGISTER OBJ = new REGISTER(name, password, cnic, vehicleno, cardno, pin, vehicletype,price);
		MEMBER.data(OBJ);
		parent.store(OBJ);
//		controler obj=new controler();
//		 obj.checkPSDETL(OBJ);
		
	}

}

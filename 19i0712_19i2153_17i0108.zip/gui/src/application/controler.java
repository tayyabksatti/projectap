package application;
import javafx.event.ActionEvent;



import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.lang.ArrayIndexOutOfBoundsException;
import java.lang.RuntimeException;
import java.lang.reflect.InvocationTargetException;
public class controler {

	
	
	
	
	
private static final boolean TRUE = false;
//__________________________________________________________________________________
	@FXML
	private TextField txtuserid;
	@FXML
	private  Label statusid;
	@FXML
	private PasswordField passid;
	@FXML
	private  Label txtrg;
	
    @FXML
    private Button mback;
	
    @FXML
    private Button txtpid;

    @FXML
    private Button txtcl;

    @FXML
    private Button txtrp;

    @FXML
    private Label slotid;
    
   //---------------------------------------------
    @FXML
    private Button back;

    @FXML
    private Label wname;

    @FXML
    private Label wvno;

    @FXML
    private Label wcnic;

    @FXML
    private Label wsno;

    @FXML
    private Label wtd;

  

   public String name;
   @FXML
   private Button vdt;
   //----------------------------------------------------------------------------------
   
   @FXML
   private Label rnm;

   @FXML
   private Label rvn;

   @FXML
   private Label rcnic;

   @FXML
   private Label rsltno;

   @FXML
   private Label rtd;

   @FXML
   private Button rvdetail;

   @FXML
   private Button rbk;

   @FXML
   private Button PVD;

   @FXML
   private Button PBACK;

   @FXML
   private Label pnam;

   @FXML
   private Label pvn;

   @FXML
   private Label pcnic;

   @FXML
   private Label psno;
   
   private REGISTER r;

   @FXML
   private Label ptdt;
   public String name1="";
   public String Cnic="";
   public String vehicleno;
  // public int price;
  // REGISTER OBJ=
   
//------------------------------------------------------------------------------
   @FXML
   void PBKTMENU(ActionEvent event)throws Exception  {

	   checkPBKTMENU();
   }

   	void checkPBKTMENU() throws Exception
   	{
   		Main m4=new Main();
		m4.start1("Menu.fxml");
   	}
   
   
   @FXML
   public void PSDETL(ActionEvent event) throws Exception {
	  checkPSDETL();
	  
   }
   
   public void checkPSDETL()
   {
	   REGISTER OBJ=new REGISTER();
	   parent obj1=new parent();
	  // System.out.print("parent name"+obj1.name);
	   //System.out.print("in controller"+OBJ.getName());
	   CARPARK obj=new CARPARK();
	   pnam.setText(obj1.name);
	   pvn.setText(obj1.vehicleno);
	   pcnic.setText(obj1.getCnic());
	   String w=Integer.toString(obj.slotno);
	   psno.setText(w);
	   ptdt.setText(obj.time_duration);
	   
	  
	  	   
   }
//------------------------------------------------------------------------------   
   
   @FXML
   void reback(ActionEvent event) throws Exception 
   {
	   checkreback();
   }

   void checkreback() throws Exception
   {
		Main m4=new Main();
		m4.start1("Menu.fxml");
   }
   
   @FXML
   void showdetail(ActionEvent event) throws Exception {
	   showdetails();
   }   
   
   void showdetails() throws Exception
   {
	   
	  // REGISTER OBJ=new REGISTER();
	   parent obj1=new parent();
	   CARPARK obj=new CARPARK();
	   rnm.setText(obj1.name);
	   rvn.setText(obj1.vehicleno);
	   rcnic.setText(obj1.getCnic());
	   String w=Integer.toString(obj.slotno);
	   rsltno.setText(w);
	   rtd.setText(obj.time_duration);
	   
   }
   
 //--------------------------------------------------------------------------   
   @FXML
   void update(ActionEvent event) {
	   checkupdate();
   }
   void checkupdate()
   {
	   
	  
	   REGISTER OBJ=new REGISTER();
	   parent obj1=new parent();
	   CARPARK obj=new CARPARK();
	  
	   
		 wname.setText(obj1.name);
    	wvno.setText(obj1.vehicleno);
    	wcnic.setText(obj1.getCnic());
    	String w=Integer.toString(obj.slotno);
    	wsno.setText(w);
    	wtd.setText(obj.time_duration);
		
   }
    @FXML
    void backtomain(ActionEvent event) throws Exception 
    {
    	checkMain();
    }
	
 private void init() throws InterruptedException
    { 
    	MThread t1=new MThread();   
   	 	t1.start();
    
    		
    }
    @FXML
    void goback(ActionEvent event)throws Exception {
    	checkgoback();
    }

    
    void checkgoback()throws Exception
    {
    	init();
    	Main m3=new Main();
		m3.start1("login.fxml");
    }
    
	void checkMain()throws Exception
    {
    	init();
    	Main m3=new Main();
		m3.start1("Menu.fxml");
    }
    
    
    
    

	@FXML
    void clean(ActionEvent event)throws Exception {
    	checkclean();
    }

    @FXML
    void park(ActionEvent event) throws Exception {
    	checkpark();
    }

    @FXML
    void repair(ActionEvent event)throws Exception {
    	checkrepair();
    }
	
		private void checkclean()throws Exception
		{
			
			
			 parent obj1=new parent();
			
				if(obj1.price==4000)
			   	{
					Main m1=new Main();
					m1.start1("car_wash.fxml");
			   	}
				else
				{
					slotid.setText(" YOU ARE NON MEMBER");
				}
			
	
			
		}
		private void checkpark()throws Exception
		{
			 parent obj1=new parent();
			 System.out.print(obj1.price+" price in park");
			if(obj1.price==5000)
		   	{
			
			Main m1=new Main();
		   	m1.start1("car_park.fxml");
		   	}
			else
			{
				slotid.setText("YOU ARE NON MEMBER ");
			}
		}
		private void checkrepair()throws Exception
		{
			 parent obj1=new parent();
			 System.out.print(obj1.price+" price in repair");
			if(obj1.price==3000)
		   	{
		  	Main m1=new Main();
		   	m1.start1("car_repair.fxml");
		   	}
			else
			{
				slotid.setText(" YOU ARE NON MEMBER");
			}
		}
		

//_____________________________________________________________________________
		
		
		
		
		
	    @FXML
	    private Button enteram;

	    @FXML
	    private TextField amoid;

	    @FXML
	    void amountenter(ActionEvent event) throws Exception
	    {
	    	checkamount();
	    }
	    void checkamount() throws Exception
	    {
	    	if(Integer.valueOf(amoid.getText())==5000)
	    	{
	    	
	    		CARPARK obj=new CARPARK(5000);
	    		obj.setAmount(4000);
	    	
	    		Main m1=new Main();
			   	m1.start1("car_park.fxml");
	    	}
	    	else if(Integer.valueOf(amoid.getText())==4000)
	    	{
	    		CARWASH obj=new CARWASH(4000);
	    		obj.setAmount(4000);
	    	
	    		Main m1=new Main();
			   	m1.start1("car_wash.fxml");
	    	}
	    	else if(Integer.valueOf(amoid.getText())==3000)
	    	{
	    		CARREPAIR obj=new CARREPAIR(3000);
	    		obj.setAmount(4000);
	    		
	    		Main m1=new Main();
			   	m1.start1("car_repair.fxml");
	    	}
	    }
		
		
		
		
		
		
//___________________________________SIGNIN____________________________________	 
	    @FXML
	    private Button txtr;

	    @FXML
	    private TextField txtus;

	    @FXML
	    private PasswordField txtps;

	    @FXML
	    private TextField txtcnic;

	    @FXML
	    private TextField txtvno;

	    @FXML
	    private TextField txtcrdno;

	    @FXML
	    private TextField txtpin;

	    @FXML
	    private TextField txtcartype;

	    @FXML
	    public Label sstatus;

	    @FXML
	    private TextField IDPRICE;
	    
	    @FXML
	    void Register(ActionEvent event) throws Exception {
	    
	    
	    	 if(txtus.getText().isEmpty())
	    	{
	    			sstatus.setText("enter your name");
	    		 throw new namenotnull("enter your name");
	    	
	    	}
	    	else if(Integer.valueOf(txtps.getText().length())<5 ||Integer.valueOf(txtps.getText().length())<5 )
	    	{
	    			sstatus.setText("Wrong to password");
				  throw new wrongpassword("wrong password ");
	    	}
	    	else if(txtcnic.getText().length()>13 ||txtcnic.getText().length()<13)
	    	{
	    		sstatus.setText("Wrong cnic no");
				  throw new wrongcniclength("enter 13 digit for cnic");
	    	}
	    	else if(txtvno.getText().length()>7)
	    	{
	    		sstatus.setText("Wrong vehicleno");
				  throw new wrongcniclength("enter 7 digit for vehicleno");
	    	}
	    	else if(txtcrdno.getText().length()>16 || txtcrdno.getText().length()<16)
	    	{
	    			sstatus.setText("Wrong cardno");
				  throw new wrongcniclength("enter 16 digit for cardno");
	    	}
	    	else if(Integer.valueOf(txtpin.getText().length())<4||Integer.valueOf(txtpin.getText().length())>4)
	    	{
	    			sstatus.setText("enter 4 digit pin");
				  throw new wrongpassword("enter 4 digit pin ");
	    	}
	    	else if(txtcartype.getText().equals(""))
	    	{
	    			sstatus.setText("enter your cartype");
	    		 throw new namenotnull("empty car type");
	    	}
	    	else if(Integer.valueOf(IDPRICE.getText()).equals(0)) 
	    	{
	    			sstatus.setText("enter postive amount");
				  throw new wrongpassword("negative amount i not except ");
	    	}
	    	else
	    	{
	    		
		    REGISTER obj=new REGISTER(txtus.getText(),Integer.valueOf(txtps.getText()),txtcnic.getText(),txtvno.getText(),txtcrdno.getText(),Integer.valueOf(txtpin.getText()),txtcartype.getText(),Integer.valueOf(IDPRICE.getText()));
		    obj.display();
	    	Main m1=new Main();
			m1.start1("price.fxml");
	    	}
	    }
	
	
  
    @FXML
    void singup(ActionEvent event) throws Exception {
   	 	
    	Main m=new Main();
    	m.start1("register.fxml");
    }
	
//______________________________LOGIN_______________________________________________    
	
    @FXML
    private Button ADID;

    @FXML
    void CHECKADMIN(ActionEvent event) throws Exception {
    	chkdm();
    }
    
    public void chkdm() throws Exception
    {
    	Main m1=new Main();
		m1.start1("ADMIN.fxml");
    }
    
    
	public void login(ActionEvent event) throws Exception
	{
		checklogin();
	}


	private void checklogin() throws Exception
	{
		
		if(txtuserid.getText().isEmpty())
		{
			 statusid.setText("please enter your name");
			 throw new namenotnull("enter your name");
		}
		else if(Integer.valueOf(passid.getText().length())<5 || Integer.valueOf(passid.getText().length())>5 ) 
		  {
			  statusid.setText("Wrong to password");
			  throw new wrongpassword("wrong password ");
		  } 
		  else 
		  {
		 	
			LOGIN obj=new LOGIN(txtuserid.getText(),Integer.valueOf(passid.getText()));
			obj.display();
			
			boolean flag=MEMBER.checker(obj);
			System.out.print("boolena");
			System.out.print(flag);
			if(flag==true)
			{//name=txtuserid.getText();
				statusid.setText(" you login Successfully");
				init();
				Main m1=new Main();
				m1.start1("Menu.fxml");	
			}
			else 
			{
				statusid.setText(" Failed to login ");
			}
			
		
			}
		
		}
	
//___________________________________________ADMIN________________________________	
	
	
    @FXML
    private TextField ADnm;

    @FXML
    private PasswordField ADps;

    @FXML
    private Button ADsb;

    @FXML
    void ADMINLOG(ActionEvent event)throws Exception
    {
    	checkad();
    	
    }
    void checkad() throws Exception
    {
    	if((ADnm.getText().toString().equals("tayyab ks"))&&(ADps.getText().toString().equals("89890")))
    	{
    		Main m1=new Main();
			m1.start1("userinfo.fxml");
    	}
    
    	
    }
 //_____________________________________ADD_EMP_AND_MEMBER_________________________
    
    
    
    
    
    @FXML
    private Button AMB;

    @FXML
    private Button AMEPL;

    @FXML
    void ADDMEMBER(ActionEvent event)  throws Exception{
    	addtomemb();
    	
    }
    void addtomemb()throws Exception
    {
    	Main m1=new Main();
		m1.start1("register.fxml");
    }

  
    @FXML
    void ADEMPL(ActionEvent event)throws Exception {
    	addempl();
    }
    void addempl()throws Exception
    {
    	Main m1=new Main();
		m1.start1("addempl.fxml");
    }

    @FXML
    private TextField EMNA;

    @FXML
    private TextField EMCNC;

    @FXML
    private TextField EMPR;

    @FXML
    private TextField EMPY;

    @FXML
    private TextField EMAG;

    @FXML
    private Button empreg;

    @FXML
    void REGISTEREMP(ActionEvent event) throws Exception {

    	checkreem();
    	
    }
    void checkreem()throws Exception
    {
    	
    	if(EMNA.getText().isEmpty())
    	{
    		
    		Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Failure");
            alert.setHeaderText(null);
            alert.setContentText("One or more Text Fields are Empty!");
            alert.showAndWait();
    		
    	}
    	else if(EMCNC.getText().length()>13 ||EMCNC.getText().length()<13)
    	{
    		
			  throw new wrongcniclength("enter 13 digit for cnic");
    	}
    	else if(Integer.valueOf(EMPY.getText())<0)
		{
			throw new wrongcniclength("enter positive amount");
		}
    	else if(Integer.valueOf(EMAG.getText())<18)
    	{
    		throw new wrongcniclength(" age  is less than 18 ");
    	}
    	else if(EMPR.getText().isEmpty())
    	{
    		Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Failure");
            alert.setHeaderText(null);
            alert.setContentText("One or more Text Fields are Empty!");
            alert.showAndWait();
    	}
    	else
    	{
    	init();
        EMPLOYEE OBJ=new EMPLOYEE(EMNA.getText(),Integer.valueOf(EMAG.getText()),EMCNC.getText(),EMPR.getText(),Integer.valueOf(EMPY.getText()));
        OBJ.display();
    	init();
    	Main m1=new Main();
		m1.start1("login.fxml");
    	}
    }

	
    
    
    
    
}

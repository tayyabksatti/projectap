package application;

public class namenotnull extends Exception{
	
	public namenotnull(String p)
	{
		super(p);
		System.out.print(p);
	}

}

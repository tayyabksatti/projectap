package application;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ testing.class })
public class AllTests {
	

	@Test
	public static void test()
	{
		
		REGISTER obj=new REGISTER("ALI", 12345, "3740425632887", "led-121", "12345678901", 1234, "car", 5000);
		if((obj.getName()=="ALI")&&(obj.getPassword()==12345)&&(obj.cnic=="3740425632887") &&(obj.vehicleno=="led-121")
		&&(obj.cardno=="3740425632887")&&(obj.pin==1234)
		&&(obj.vehicletype=="car")&&(obj.price==5000))
		{

			assertTrue(true);
		}
	}

}

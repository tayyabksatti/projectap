package application;

class MThread extends Thread{    
 public void run()
 {    
  for(int i=1;i<5;i++)
  {   
  // the thread will sleep for the 500 milli seconds   
    try{
    	Thread.sleep(500);
    	System.out.println(i);  
    }catch(InterruptedException e)
    {
    	System.out.println(e);
    	}    
    
      
  }    
 }   
}
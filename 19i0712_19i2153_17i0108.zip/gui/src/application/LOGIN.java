package application;

public class LOGIN {
		public String name;
		public int password;
		public LOGIN(String n,int p)
		{
			name=n;
			password=p;
			
				
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getPassword() {
			return password;
		}
		public void setPassword(int password) {
			this.password = password;
		}
		
		public void display()
		{
			System.out.print(name);
			//System.out.print(password);
			LOGIN OBJ=new LOGIN(name,getPassword());
			MEMBER.readdata(OBJ);
		}
		
			
}

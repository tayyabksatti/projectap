package application;

public class ADMIN {
private String name;
private int password;


public ADMIN(String name, int password) {
	super();
	this.name = name;
	this.password = password;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getPassword() {
	return password;
}
public void setPassword(int password) {
	this.password = password;
}





	
	
	

}

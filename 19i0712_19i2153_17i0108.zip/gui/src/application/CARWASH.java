package application;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class CARWASH {

	Date date = new Date();
	SimpleDateFormat formatTime = new SimpleDateFormat("hh.mm aa");
	String time = formatTime.format( date); // changing the format of 'date'
	private static final AtomicInteger count = new AtomicInteger(1); 
	int amount=0;
	int slotno=count.incrementAndGet();
	String time_duration=time;
	public CARWASH()
	{
		
	}
	public CARWASH(int price)
	{
		amount=price;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public SimpleDateFormat getFormatTime() {
		return formatTime;
	}
	public void setFormatTime(SimpleDateFormat formatTime) {
		this.formatTime = formatTime;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getSlotno() {
		return slotno;
	}
	public void setSlotno(int slotno) {
		this.slotno = slotno;
	}
	public String getTime_duration() {
		return time_duration;
	}
	public void setTime_duration(String time_duration) {
		this.time_duration = time_duration;
	}
	public static AtomicInteger getCount() {
		return count;
	}
	
	
	
}

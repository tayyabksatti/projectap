package application;

public class parent {

	public REGISTER OBJ;
	public LOGIN OBJ1;
	public static String name;
	int password;
	static String cnic;
	public static String vehicleno;
	String cardno;
	int pin;
	String vehicletype;
	public static int price;
	
	public static void store(REGISTER OBJ)
	{
		name=OBJ.name;
		cnic=OBJ.getCnic();
		vehicleno=OBJ.vehicleno;
		 price=OBJ.price;
		
	}
	public REGISTER getOBJ() {
		return OBJ;
	}
	public void setOBJ(REGISTER oBJ) {
		OBJ = oBJ;
	}
	public LOGIN getOBJ1() {
		return OBJ1;
	}
	public void setOBJ1(LOGIN oBJ1) {
		OBJ1 = oBJ1;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public String getCnic() {
		return cnic;
	}
	public void setCnic(String cnic) {
		this.cnic = cnic;
	}
	public String getVehicleno() {
		return vehicleno;
	}
	public void setVehicleno(String vehicleno) {
		this.vehicleno = vehicleno;
	}
	public String getCardno() {
		return cardno;
	}
	public void setCardno(String cardno) {
		this.cardno = cardno;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getVehicletype() {
		return vehicletype;
	}
	public void setVehicletype(String vehicletype) {
		this.vehicletype = vehicletype;
	}
	
	
	
}

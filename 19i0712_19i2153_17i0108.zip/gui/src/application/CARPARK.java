package application;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class CARPARK {
	  
	Date date = new Date();
	SimpleDateFormat formatTime = new SimpleDateFormat("hh.mm aa");
     String time = formatTime.format(date); 
	private static final AtomicInteger count = new AtomicInteger(0); 
	public int amount;
	public int slotno=count.incrementAndGet();
	public String time_duration=time;
	
	public CARPARK() {
		// TODO Auto-generated constructor stub
	}

	public CARPARK(int price) {
		// TODO Auto-generated constructor stub
		amount=price;
	}



	public Date getDate() {
		return date;
	}



	public void setDate(Date date) {
		this.date = date;
	}



	public SimpleDateFormat getFormatTime() {
		return formatTime;
	}



	public void setFormatTime(SimpleDateFormat formatTime) {
		this.formatTime = formatTime;
	}



	public String getTime() {
		return time;
	}



	public void setTime(String time) {
		this.time = time;
	}



	public int getAmount() {
		return amount;
	}



	public void setAmount(int amount) {
		this.amount = amount;
	}



	public int getSlotno() {
		return slotno;
	}



	public void setSlotno(int slotno) {
		this.slotno = slotno;
	}



	public String getTime_duration() {
		return time_duration;
	}



	public void setTime_duration(String time_duration) {
		this.time_duration = time_duration;
	}



	public static AtomicInteger getCount() {
		return count;
	}






		
	
	
	
	
}

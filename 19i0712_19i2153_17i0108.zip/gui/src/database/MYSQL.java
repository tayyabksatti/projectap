package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import application.EMPLOYEE;
import application.MEMBER;

public class MYSQL {

	
	public static void add_MEMBER(MEMBER d) {
		//System.out.println("-=-=-=-");
		try {
			String url="jdbc:mysql://localhost:3306/testdb";
			Connection con=DriverManager.getConnection(url,"root","tayyabks129");
			Statement stmt=con.createStatement();

			String query="insert into member (name,pass,cnic,vehicleno,cardno,pin,vehicletype,price)" + " values ('"+d.name1+"',"+d.password1+",'"+d.cnic+"','"+d.vehicleno+"','"+d.cardno+"',"+d.pin+",'"+d.vehicletype+"',"+d.price+")";
			System.out.println(query);
			stmt.executeUpdate(query);
			con.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public  void add_EMPLOYEE(EMPLOYEE d) {
		//System.out.println("-=-=-=-");
		try {
			String url="jdbc:mysql://localhost:3306/testdb";
			Connection con=DriverManager.getConnection(url,"root","tayyabks129");
			Statement stmt=con.createStatement();

			String query="insert into employee (name,cnic,pay,prof,age)" + " values ('"+d.name+"',"+d.cnic+",'"+d.pay+"','"+d.prof+"','"+d.age+"')";
			System.out.println(query);
			stmt.executeUpdate(query);
			con.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
}
